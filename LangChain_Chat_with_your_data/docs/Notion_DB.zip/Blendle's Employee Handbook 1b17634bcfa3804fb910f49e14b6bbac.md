# Blendle's Employee Handbook

This is a living document with everything we've learned working with people while running a startup. And, of course, we continue to learn. Therefore it's a document that will continue to change. 

**Everything related to working at Blendle and the people of Blendle, made public.**

These are the lessons from three years of working with the people of Blendle. It contains everything from [how our leaders lead](https://www.notion.so/ecfb7e647136468a9a0a32f1771a8f52?pvs=21) to [how we increase salaries](https://www.notion.so/e11b6161c6d34f5c9568bb3e83ed96b6?pvs=21), from [how we hire](https://www.notion.so/451bbcfe8d9b49438c0633326bb7af0a?pvs=21) and [fire](https://www.notion.so/5567687a2000496b8412e53cd58eed9d?pvs=21) to [how we think people should give each other feedback](https://www.notion.so/eb64f1de796b4350aeab3bc068e3801f?pvs=21) — and much more.

We've made this document public because we want to learn from you. We're very much interested in your feedback (including weeding out typo's and Dunglish ;)). Email us at hr@blendle.com. If you're starting your own company or if you're curious as to how we do things at Blendle, we hope that our employee handbook inspires you.

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).

## Blendle general

*Information gap closing in 3... 2... 1...*

---

[To Do/Read in your first week](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/To%20Do%20Read%20in%20your%20first%20week%201b17634bcfa38112a4adc62db85eb93c.md)

[History](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/History%201b17634bcfa3811493bdde3b13ca63b3.md)

[DNA & culture](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/DNA%20&%20culture%201b17634bcfa38183a0d3e1719fa36d66.md)

[General & practical ](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/General%20&%20practical%201b17634bcfa381b4ab7aeb71e5c35d4a.md)

## People operations

*You can tell a company's DNA by looking at how they deal with the practical stuff.*  

---

[Office](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Office%201b17634bcfa381e6af85fbf0245b61fc.md)

[Time off: holidays and national holidays](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Time%20off%20holidays%20and%20national%20holidays%201b17634bcfa381a9aafbf1e7980c5b5c.md)

[Calling in sick/better](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Calling%20in%20sick%20better%201b17634bcfa38117a3a4ed63eac96d2c.md)

[Perks and benefits](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Perks%20and%20benefits%201b17634bcfa3815e98d2e828d0d89649.md)

[Travel costs and reimbursements](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Travel%20costs%20and%20reimbursements%201b17634bcfa3818fa404ffa153497595.md)

[Parenthood](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Parenthood%201b17634bcfa38185ae68e6f2efce6bbb.md)

## People topics

*Themes we care about.*

---

[Blendle Social Code](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Blendle%20Social%20Code%201b17634bcfa3816f9255ff4fdb9a464c.md)

[Diversity and inclusion](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Diversity%20and%20inclusion%201b17634bcfa3810cbb1aeb458d515de8.md)

[#letstalkaboutstress](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/#letstalkaboutstress%201b17634bcfa38170a42ee4f9b52cb0fd.md)

## Feedback and development

*The number 1 reason for people to work at Blendle is growth and learning from smart people.*

---

[Your 1st month ](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Your%201st%20month%201b17634bcfa3817b929ecc9c15867fab.md)

[Goals](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Goals%201b17634bcfa381099703db9a65189d1d.md)

[Feedback cycle](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Feedback%20cycle%201b17634bcfa381d4bab4e52b2a05b39f.md)

[The Matrix™ (job profiles)](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/The%20Matrix%E2%84%A2%20(job%20profiles)%201b17634bcfa3818cb5a5de20d380377b.md)

[Blendle library](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Blendle%20library%201b17634bcfa381f69a89c981f45b8948.md)

## **Hiring**

*The coolest and most impactful thing when done right.*

---

[Rating systems](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Rating%20systems%201b17634bcfa381369556c7460789c98a.md)

[Getting people in (branding&sourcing)](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Getting%20people%20in%20(branding&sourcing)%201b17634bcfa381c58762c0abe820ff7b.md)

[Highly Skilled Migrants and relocation](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Highly%20Skilled%20Migrants%20and%20relocation%201b17634bcfa38185a918e8b53362a889.md)

## How to lead at Blendle

*Here are some tips and tools to help you become a great leader.*

---

[How to lead at Blendle ](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/How%20to%20lead%20at%20Blendle%201b17634bcfa3815aaa89efbe8754bb2c.md)

[Your check-list](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Your%20check-list%201b17634bcfa3815e9755df83960f7055.md)

[Leading Feedback ](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Leading%20Feedback%201b17634bcfa38122b1bfc2ad3d75c9e2.md)

[Salary talks](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Salary%20talks%201b17634bcfa381a28f20f9302b517e98.md)

[Hiring ](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Hiring%201b17634bcfa381f6bc71c27308f90e6c.md)

[Firing](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Firing%201b17634bcfa3812daf32d34d51e10ceb.md)

[Party and study budget](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Party%20and%20study%20budget%201b17634bcfa3818b96c7c5efaf89f57a.md)

[Holidays](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Holidays%201b17634bcfa381d39298fc374f86e05a.md)

[Sickness absence](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Sickness%20absence%201b17634bcfa3813aac6be51862b1d9e4.md)

[Personal User Guide](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Personal%20User%20Guide%201b17634bcfa381c18771d0cbd3a92441.md)

[Soft shizzle](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/Soft%20shizzle%201b17634bcfa381ab9f2ef171cfa555b3.md)

## About this document

---

*Lessons from three years of HR*

[About this document and the author](Blendle's%20Employee%20Handbook%201b17634bcfa3804fb910f49e14b6bbac/About%20this%20document%20and%20the%20author%201b17634bcfa381859858c09f20cdbce7.md)