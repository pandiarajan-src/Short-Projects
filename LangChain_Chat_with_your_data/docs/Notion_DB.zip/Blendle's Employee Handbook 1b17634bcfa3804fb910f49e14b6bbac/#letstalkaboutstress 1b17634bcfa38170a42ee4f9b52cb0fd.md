# #letstalkaboutstress

Let’s talk about stress. Too much stress. 

We know this can be a topic.

So let’s get this conversation going. 

[Intro: two things you should know](#letstalkaboutstress%201b17634bcfa38170a42ee4f9b52cb0fd/Intro%20two%20things%20you%20should%20know%201b17634bcfa3819686c0f8b0f1dd45e3.md)

[What is stress](#letstalkaboutstress%201b17634bcfa38170a42ee4f9b52cb0fd/What%20is%20stress%201b17634bcfa381f3b214fdf7d7ae6b23.md)

[When is there too much stress?](#letstalkaboutstress%201b17634bcfa38170a42ee4f9b52cb0fd/When%20is%20there%20too%20much%20stress%201b17634bcfa381bab660f3ca599fc0bd.md)

[What can I do](#letstalkaboutstress%201b17634bcfa38170a42ee4f9b52cb0fd/What%20can%20I%20do%201b17634bcfa38194b7d9e3a754af7f95.md)

[What can Blendle do?](#letstalkaboutstress%201b17634bcfa38170a42ee4f9b52cb0fd/What%20can%20Blendle%20do%201b17634bcfa38182855ecf509cab9742.md)

[Good reads](#letstalkaboutstress%201b17634bcfa38170a42ee4f9b52cb0fd/Good%20reads%201b17634bcfa381ecbe24e10eae67b8eb.md)

Go to **#letstalkaboutstress** on slack to chat about this topic

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).