# How to lead at Blendle

This section is dedicated to all the people who are in some way in a lead role. This will give you  all the info, context, background, tools, processes and frameworks you need to lead. This should equip you to make decisions. This doesn't mean your are on your own in this. Please ask for help.

Before you dig in, read this piece (with 6 must reads in it).

[Our 6 Must Reads for First-Time Managers to Hit the Ground Running](http://firstround.com/review/our-6-must-reads-for-first-time-managers-to-hit-the-ground-running/)

---

[Your check-list](Your%20check-list%201b17634bcfa3815e9755df83960f7055.md)

---

[Leading Feedback ](Leading%20Feedback%201b17634bcfa38122b1bfc2ad3d75c9e2.md)

[Salary talks](Salary%20talks%201b17634bcfa381a28f20f9302b517e98.md)

[Hiring ](Hiring%201b17634bcfa381f6bc71c27308f90e6c.md)

[Firing](Firing%201b17634bcfa3812daf32d34d51e10ceb.md)

[Party and study budget](Party%20and%20study%20budget%201b17634bcfa3818b96c7c5efaf89f57a.md)

[Holidays](Holidays%201b17634bcfa381d39298fc374f86e05a.md)

[Personal User Guide](Personal%20User%20Guide%201b17634bcfa381c18771d0cbd3a92441.md)

[Soft shizzle](Soft%20shizzle%201b17634bcfa381ab9f2ef171cfa555b3.md)

[Sickness absence](Sickness%20absence%201b17634bcfa3813aac6be51862b1d9e4.md)

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).