# Team sync 21 Oct

- Demo moved to Thursday
- Priya owns slides
