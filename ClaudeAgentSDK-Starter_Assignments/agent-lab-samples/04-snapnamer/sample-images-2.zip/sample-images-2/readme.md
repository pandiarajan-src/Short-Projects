# Batch 2
Includes two similar pie charts and one blurry photo on purpose.
